<?php
		include('connection.php');

		if(isSet($_GET['iUpdate'])){
		$id=$_GET['iID'];
		$username=$_GET['iUsername'];
			if(isSet($id) && $username != ""  && $id != ""){
				$query = " UPDATE users SET username='$username' WHERE userID='$id'";
				$conn->query($query);
				$query="SELECT userID,username FROM users WHERE userID='$id' ";

			}
		}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
	input{
		margin: 5px;
	}
	a{
		text-decoration: none;
		border: 2px solid teal;
		background: white;
		color: teal;
		padding: 6px;
	}
	a:hover{
		color:white;
		background: teal;
	}
	</style>
</head>

<body>
	<form action="" method="get">
	<fieldset style="width:300px">
	  <legend>Update Username</legend>
		ID    &emsp;  &emsp;  &emsp;  &ensp; &nbsp; &nbsp;:<input type="text" name="iID" style="margin-left:87">
		<br>
		New Username  :<input type="text" name="iUsername">
		<br>
	  <input type="submit" name="iUpdate" value="UPDATE">
	</fieldset>
	</form>
	<br>
	<a href="users.php"> BACK </a>
	<br>
	<br>

	<?php
			if(isSet($_GET['iUpdate'])){

					if($result=$conn->query($query)){

						while($row = $result->fetch_array()){
							echo "<hr>";
							echo "Username for ID ".$row['userID']." is updated <br>";
							echo "New username: ".$row['username'];
						}
			}
		}
	?>
</body>
</html>
