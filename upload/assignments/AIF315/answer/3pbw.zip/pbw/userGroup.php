<?php
	include('connection.php');
	$query="SELECT name FROM usergroups";
	if(isSet($_GET['iSubmit'])){
	$name=$_GET['iGroup'];
		if(isSet($name) && $name != ""){
			$query = " INSERT INTO usergroups (name) VALUES ('$name')";
			$conn->query($query);
			$query="SELECT name FROM usergroups";

		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<table>
		<tr>
			<th>Role</th>
		</tr>




		<?php
		if($result=$conn->query($query)){
			while($row=$result->fetch_array()){
				echo "<tr>";

				echo "<td>".$row['name']."</td>";

				echo "</tr>";
			}
		}

		?>
		</table>
		<br>
			<form action="" method="get">
				<fieldset>
				  <legend>Add New Role</legend>
				  <input type="text" name="iGroup">
				  <input type="submit" name="iSubmit" value="ADD">
				</fieldset>
			</form>

</body>
</html>
