INSERT INTO Users (userID, name, username, pass, ID_UG)
VALUES ('20160065', 'Maria Veronica Claudia', '16065', 'mvc', 1);
INSERT INTO Users (userID, name, username, pass, ID_UG)
VALUES ('20130053', 'Husnul Hakim', '13053', 'huh', 1);
INSERT INTO Users (userID, name, username, pass, ID_UG)
VALUES ('2011730053', 'MARIA VERONICA', '7311053', 'marichan', 2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2011730103','JOHANES MARIO ADRIANO','7311103','7311103',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2012730027','NICHOLAS MARTIN PRIBADI','7312027','7312027',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2012730078','RIZQI PUTRA PRATAMA','7312078','7312078',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2012730093','YOHAN STURE ENANDER','7312093','7312093',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730001','ALVIN IRAWAN','7313001','7313001',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730002','CHERIA','7313002','7313002',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730003','FADHIL AHSAN','7313003','7313003',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730004','CLARA','7313004','7313004',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730005','ALDY MARCELLINO CHRISTIAN','7313005','7313005',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730006','ANTONIUS','7313006','7313006',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730008','ENRICOFINDLEY','7313008','7313008',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730009','ROMMY KURNIAWAN WIJAYA','7313009','7313009',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730010','YOSUA YUUTA BIMA PRAMANA','7313010','7313010',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730011','RICKY SLAMAT PUTRA','7313011','7313011',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730012','CLAUDIA VERONICA HANURAWAN','7313012','7313012',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730013','AXEL RAHARJA','7313013','7313013',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730019','IGNASIUS DAVID YULIANUS','7313019','7313019',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730021','ERLANGGA LAIMENA','7313021','7313021',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730024','MARKUS EDWIN SOEGIANTO','7313024','7313024',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730025','GAVRILA TIOMINAR','7313025','7313025',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730029','KEVIN RIZKHY TANUJAYA','7313029','7313029',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730033','JACINTA DELORA','7313033','7313033',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730046','ANDRIANTO SUGIARTO','7313046','7313046',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730052','FRANSISCUS EVAN KRISTIAN','7313052','7313052',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730053','SOHUTURON FERNANDO','7313053','7313053',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730054','MICHAEL WILLIAM KINSEY','7313054','7313054',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730057','MAUDY NUR AVIANTI','7313057','7313057',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730058','ADRIAN REYNALDI','7313058','7313058',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730060','HARSETO PANDITYO','7313060','7313060',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730065','JONATHAN SURYA','7313065','7313065',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730068','REZA ZACKY RAMADAN','7313068','7313068',2);
INSERT INTO users (userID, name, username, pass, ID_UG)
VALUES ('2013730069','RICKY WAHYUDI','7313069','7313069',2);