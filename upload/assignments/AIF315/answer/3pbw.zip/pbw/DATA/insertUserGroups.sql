INSERT INTO usergroups(name) VALUES ('lecturer');
INSERT INTO usergroups(name) VALUES ('student');