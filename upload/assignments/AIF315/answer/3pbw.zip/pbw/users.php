<?php
	include('connection.php');
	$query="SELECT * FROM user_data";
	if(isSet($_GET['iSubmit'])){
	$name=$_GET['iName'];
		if(isSet($name) && $name != ""){
			$query .= " WHERE name LIKE '%$name%'";
		}
	}
	$start=0;
	$show=8;
	$pageCount =$conn->query($query)->num_rows/$show;

	if(isSet($_GET['start'])){
		$start=$_GET['start'];
	}
	$query.=" LIMIT $start, $show";
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
<style>
a{
	text-decoration: none;
	border: 2px solid teal;
	background: white;
	color: teal;
	padding: 6px;
}
a:hover{
	color:white;
	background: teal;
}
</style>


</head>

<body>
	<form action="" method="get">
	<fieldset>
	  <legend>Search by Name</legend>
	  <input type="text" name="iName">
	  <input type="submit" name="iSubmit" value="Search">
	</fieldset>
	</form>
	<br>
	<a href="update.php"> UPDATE </a>
	<br>
	<br>

	<hr>
	<br>
	<?php
	if ($pageCount > 1) {
			echo "<a href = 'users.php'>1</a> ";
			for ($i = 1; $i < $pageCount; $i++) {
				$str = $i * $show;
				echo "<a href = 'users.php?start=$str'>".($i + 1)."</a> ";
			}
			echo "<br><br>";
		}
	?>

	<table>
		<tr>
			<th>User ID</th>
			<th>Name</th>
			<th>Role</th>
		</tr>
		<?php
			if($result=$conn->query($query)){
				while($row=$result->fetch_array()){
					echo "<tr>";
					echo "<td>".$row['userID']."</td>";
					echo "<td>".$row['name']."</td>";
					echo "<td>".$row['role']."</td>";
					echo "</tr>";
				}
			}
		?>
	</table>
</body>
</html>
