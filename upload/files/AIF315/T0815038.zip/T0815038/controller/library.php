

<?php
	include('controller/book.php');
class Library {
	function rent($p1,$p2,$p3){
		$object=new Book($p1,$p2);
		$date=$this->calculateReturnDate($p3);
		$arr=array("book"=>$object,"return_date"=>$date);
		return $arr;
	}

	function calculateReturnDate($p1){
		$date=new DateTime();
		$return_date= $date->modify('+'.$p1.' day');
		$return_date = $date->format('d-m-Y');
		return $return_date;
	}



}




?>
