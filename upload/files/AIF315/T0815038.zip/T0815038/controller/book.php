<?php

class Book{
	private $title;
	private $author;

	function Book($p1,$p2){
		$this->title=$p1;
		$this->author=$p2;

	}
	function getTitle(){
		return $this->title;
	}

	function getAuthor(){
		return $this->author;
	}
}



?>
