<?php
		include('controller/library.php');

		$success=false;
		$data=array();
	//echo 'Request diterima'; //TODO : dihapus
	if((isset($_GET['title']))&&(isset($_GET['author']))&&(isset($_GET['duration']))){
		if((!empty($_GET['title']))&&(!empty($_GET['author']))&&(!empty($_GET['duration']))&&(($_GET['duration'])>0)){


	  $success=true;

		$library=new Library();
		$data=$library->rent($_GET['title'],$_GET['author'],$_GET['duration']);
		}
	}
	else{
		 $success=false;


	}
?>

<?php

	include('layout/header.php');

	if($success==true){
		echo 'Judul buku : '.$data['book']->getTitle();
		echo '<br>';
		echo 'Pengarang : '.$data['book']->getAuthor();
		echo '<br>';
		echo 'Tanggal Pengembalian : '.$data['return_date'];
		echo '<br>';
	}
	else{
		echo 'Transaksi Gagal';
		echo '<br>';
	}


	include('layout/footer.php');
?>
